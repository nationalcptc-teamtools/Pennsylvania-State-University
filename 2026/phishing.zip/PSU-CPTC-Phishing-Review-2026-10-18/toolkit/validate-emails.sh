#!/usr/bin/env bash
# Observes RCPT response; does not certify mailbox existence.
set -euo pipefail
exec python3 "$(cd -- "$(dirname -- "$0")" && pwd)/campaign.py" --probe "$@"
