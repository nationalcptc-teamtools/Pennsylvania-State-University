#!/usr/bin/env bash
# Render-only by default. Legacy environment variables no longer enable sends.
set -euo pipefail
exec python3 "$(cd -- "$(dirname -- "$0")" && pwd)/campaign.py" "$@"
