#!/usr/bin/env python3
"""Authorized simulation server: records events, never submitted secrets."""
import argparse
import datetime
import http.server
import json
import os
from pathlib import Path
import ssl
import threading
import urllib.parse

PAGES = {'/psp-login.html', '/mfa-setup.html', '/ai-platform.html'}
MAX_BODY = 8192

class SimulationServer(http.server.ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, address, directory, log_file):
        self.directory = Path(directory).resolve(strict=True)
        self.log_file = Path(log_file).resolve()
        if self.log_file.is_relative_to(self.directory):
            raise ValueError('Event log must be outside the served directory')
        self.log_file.parent.mkdir(parents=True, exist_ok=True)
        self.log_lock = threading.Lock()
        super().__init__(address, Handler)

    def event(self, kind):
        entry = {'timestamp': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'event': kind}
        with self.log_lock:
            fd = os.open(self.log_file, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o600)
            with os.fdopen(fd, 'a', encoding='utf-8') as stream:
                stream.write(json.dumps(entry) + '\n')

class Handler(http.server.BaseHTTPRequestHandler):
    def setup(self):
        super().setup()
        self.connection.settimeout(10)

    def log_message(self, *args):
        pass  # Do not log untrusted URLs or form values.

    def reply(self, code, body=b'', content_type='text/html; charset=utf-8', head=False):
        self.send_response(code)
        for name, value in {'Content-Type': content_type, 'Content-Length': str(len(body)),
                            'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff',
                            'Referrer-Policy': 'no-referrer', 'X-Frame-Options': 'DENY'}.items():
            self.send_header(name, value)
        self.end_headers()
        if not head:
            self.wfile.write(body)

    def do_GET(self):
        self.get_page(False)

    def do_HEAD(self):
        self.get_page(True)

    def get_page(self, head):
        path = urllib.parse.urlsplit(self.path).path
        if path == '/complete':
            return self.reply(200, b'<h1>Simulation complete</h1><p>No submitted passwords were retained.</p>', head=head)
        if path == '/health':
            return self.reply(200, b'ok', 'text/plain', head=head)
        if path not in PAGES:
            return self.reply(404, b'Not found', 'text/plain', head=head)
        file = self.server.directory / path[1:]
        if file.is_symlink() or not file.resolve().is_relative_to(self.server.directory) or not file.is_file():
            return self.reply(404, b'Not found', 'text/plain', head=head)
        body = file.read_bytes()
        if not head:
            self.server.event('page_view:' + path)
        self.reply(200, body, head=head)

    def do_POST(self):
        if self.path != '/capture':
            return self.reply(404, b'Not found', 'text/plain')
        if self.headers.get('Transfer-Encoding'):
            return self.reply(400, b'Unsupported transfer encoding', 'text/plain')
        if self.headers.get_content_type() != 'application/x-www-form-urlencoded':
            return self.reply(415, b'Expected form data', 'text/plain')
        lengths = self.headers.get_all('Content-Length', [])
        if len(lengths) != 1 or not lengths[0].isascii() or not lengths[0].isdigit():
            return self.reply(400, b'Invalid length', 'text/plain')
        size = int(lengths[0])
        if size > MAX_BODY:
            return self.reply(413, b'Body too large', 'text/plain')
        try:
            body = self.rfile.read(size)
        except TimeoutError:
            return self.reply(408, b'Request timeout', 'text/plain')
        if len(body) != size:
            return self.reply(400, b'Incomplete body', 'text/plain')
        del body  # Event evidence only; no passwords, tokens or usernames stored.
        self.server.event('form_submitted')
        self.send_response(303)
        self.send_header('Location', '/complete')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Length', '0')
        self.end_headers()

def main():
    here = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bind', default='127.0.0.1')
    parser.add_argument('--port', type=int, default=8080)
    parser.add_argument('--dir', type=Path, default=here)
    parser.add_argument('--log', type=Path, default=here.parent/'private-output'/'events.jsonl')
    parser.add_argument('--ssl', action='store_true')
    parser.add_argument('--cert', type=Path)
    parser.add_argument('--key', type=Path)
    args = parser.parse_args()
    context = None
    if args.ssl:
        if not args.cert or not args.key:
            parser.error('--ssl requires --cert and --key')
        if args.key.resolve().is_relative_to(args.dir.resolve()):
            parser.error('TLS private key must be outside the served directory')
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.minimum_version = ssl.TLSVersion.TLSv1_2
        context.load_cert_chain(args.cert.resolve(), args.key.resolve())
    elif args.cert or args.key:
        parser.error('Use --ssl with certificate options')
    with SimulationServer((args.bind, args.port), args.dir, args.log) as server:
        if context:
            server.socket = context.wrap_socket(server.socket, server_side=True)
        print(f"Listening on {'https' if context else 'http'}://{args.bind}:{server.server_port}", flush=True)
        print('Event-only logging; submitted passwords are discarded.', flush=True)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass

if __name__ == '__main__':
    main()
