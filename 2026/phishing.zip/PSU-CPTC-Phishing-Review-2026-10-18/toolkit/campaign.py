#!/usr/bin/env python3
"""Render first; explicitly opt in to approved SMTP tests. Standard library only."""
import argparse
import datetime
from email import policy
from email.parser import Parser
from email.utils import formatdate, make_msgid, formataddr
import html
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import time
import urllib.parse
import uuid

HERE = Path(__file__).resolve().parent
ADDRESS = r"[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}"

def addresses(path):
    result = []
    for line in Path(path).read_text(encoding='utf-8-sig').splitlines():
        value = line.strip()
        if not value or value.startswith('#'):
            continue
        if not re.fullmatch(ADDRESS, value):
            raise ValueError('Invalid recipient line; use one plain address per line')
        if value not in result:
            result.append(value)
    if not result:
        raise ValueError('Recipient list is empty')
    return result

def header(message, name, value):
    if '\r' in value or '\n' in value:
        raise ValueError('Header newline rejected')
    if message.get(name) is not None:
        message.replace_header(name, value)
    else:
        message[name] = value

def render(template, target, link, sender, name):
    url = urllib.parse.urlsplit(link)
    if url.scheme not in ('http', 'https') or not url.hostname or url.username or url.password or any(c in link for c in '\r\n'):
        raise ValueError('Provide an HTTP(S) landing URL without credentials')
    if 'PLACEHOLDER' in link or 'YOUR_' in link:
        raise ValueError('Replace landing URL placeholders')
    message = Parser(policy=policy.SMTP).parsestr(Path(template).read_text(encoding='utf-8'))
    if any(part.defects for part in message.walk()):
        raise ValueError('Malformed MIME template')
    now = formatdate(localtime=False, usegmt=True)
    for part in message.walk():
        if part.is_multipart():
            continue
        if part.get_content_type() not in ('text/plain', 'text/html'):
            raise ValueError('Runner supports text/HTML simulations, not executable attachments')
        text = part.get_content()
        for key, value in {'TARGET_PLACEHOLDER': target, 'DATE_PLACEHOLDER': now, 'LINK_PLACEHOLDER': link}.items():
            text = text.replace(key, html.escape(value, quote=True) if part.get_content_type() == 'text/html' else value)
        part.set_content(text, subtype=part.get_content_subtype(), charset='utf-8')
    header(message, 'To', target)
    header(message, 'Date', now)
    header(message, 'From', formataddr((name, sender)))
    header(message, 'Message-ID', make_msgid(domain=sender.split('@')[-1]))
    output = message.as_bytes()
    if re.search(rb'[A-Z][A-Z_]*PLACEHOLDER|YOUR_LANDING_PAGE|YOUR_ATTACK_IP', output):
        raise ValueError('Unresolved template placeholder')
    return output

def classify_rcpt(transcript):
    awaiting = False
    for line in transcript.splitlines():
        if re.search(r'RCPT TO\s*:', line, re.I) and re.match(r'^\s*[-~]>', line):
            awaiting = True
            continue
        if awaiting:
            if re.match(r'^\s*[-~]>', line):
                return 'indeterminate', None
            match = re.match(r'^\s*<[-~*]+\s*(\d{3})([ -])', line)
            if match and match[2] == ' ':
                code = int(match[1])
                return ('accepted' if 200 <= code < 300 else 'rejected' if code >= 500 else 'indeterminate', code)
    return 'indeterminate', None

def run(args):
    targets = addresses(args.targets)
    if len(targets) > args.max_recipients:
        raise ValueError('Recipient cap exceeded')
    if not 0 <= args.delay <= 3600 or not 1 <= args.port <= 65535:
        raise ValueError('Invalid delay or port')
    if args.send and args.probe:
        raise ValueError('Choose send OR probe')
    live = args.send or args.probe
    if live:
        if not args.server or not args.approved_targets:
            raise ValueError('Live operations require --server and --approved-targets')
        if not set(targets).issubset(set(addresses(args.approved_targets))):
            raise ValueError('Recipient not in approved list')
        if not shutil.which('swaks'):
            raise ValueError('SWAKS is not installed; rendering works without it')
    if not re.fullmatch(ADDRESS, args.sender) or any(c in args.name for c in '\r\n'):
        raise ValueError('Invalid sender or display name')
    out = Path(args.output).resolve()
    if out.is_relative_to((HERE/'landing-pages').resolve()):
        raise ValueError('Output must be outside landing-pages')
    messages = [] if args.probe else [render(args.template, t, args.link, args.sender, args.name) for t in targets]
    directory = out/('run-' + uuid.uuid4().hex[:12])
    directory.mkdir(parents=True, mode=0o700)
    records = []
    for index, target in enumerate(targets):
        record = {'recipient': target, 'timestamp': datetime.datetime.now(datetime.timezone.utc).isoformat()}
        command = ['swaks', '--server', args.server or 'UNSET', '--port', str(args.port), '--to', target, '--from', args.sender, '--timeout', '20s']
        if args.tls == 'starttls':
            command += ['--tls', '--tls-verify']
        elif args.tls == 'implicit':
            command += ['--tls-on-connect', '--tls-verify']
        if args.probe:
            command += ['--quit-after', 'RCPT']
        else:
            file = directory/f'{index+1:03}.eml'
            file.write_bytes(messages[index])
            os.chmod(file, 0o600)
            command += ['--data', '@' + str(file)]
            record['message_file'] = str(file)
        if not live:
            record['outcome'] = 'rendered_only'
        else:
            try:
                response = subprocess.run(command, capture_output=True, text=True, timeout=60, check=False)
                transcript = response.stdout + response.stderr
                if args.probe:
                    record['outcome'], record['smtp_code'] = classify_rcpt(transcript)
                else:
                    record['outcome'] = 'smtp_accepted' if response.returncode == 0 else 'failed'
                record['exit_code'] = response.returncode
                log = directory/f'{index+1:03}.smtp.txt'
                log.write_text(transcript, encoding='utf-8')
                os.chmod(log, 0o600)
            except subprocess.TimeoutExpired:
                record['outcome'] = 'timeout_delivery_unknown'
            except OSError:
                record['outcome'] = 'execution_error'
        records.append(record)
        log = directory/'results.json'
        log.write_text(json.dumps(records, indent=2), encoding='utf-8')
        os.chmod(log, 0o600)
        print(f'{index+1}/{len(targets)}: {record["outcome"]}')
        if live and index < len(targets)-1:
            time.sleep(args.delay)
    print(f'Results: {directory}')
    print('SMTP acceptance is not inbox delivery; RCPT acceptance does not prove mailbox existence.')
    return int(any(r['outcome'] in ('failed', 'execution_error', 'timeout_delivery_unknown', 'rejected', 'indeterminate') for r in records))

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('targets', type=Path)
    parser.add_argument('template', type=Path, nargs='?', default=HERE/'templates'/'psp-alert.eml')
    parser.add_argument('--link', default='http://127.0.0.1:8080/psp-login.html')
    parser.add_argument('--sender', default='exercise@example.test')
    parser.add_argument('--name', default='Authorized Exercise')
    parser.add_argument('--server')
    parser.add_argument('--port', type=int, default=25)
    parser.add_argument('--tls', choices=['starttls', 'implicit', 'none'], default='starttls')
    parser.add_argument('--approved-targets', type=Path)
    parser.add_argument('--max-recipients', type=int, default=10)
    parser.add_argument('--delay', type=float, default=30)
    parser.add_argument('--output', type=Path, default=HERE/'private-output')
    parser.add_argument('--send', action='store_true')
    parser.add_argument('--probe', action='store_true')
    args = parser.parse_args()
    try:
        return run(args)
    except (ValueError, OSError) as error:
        parser.error(str(error))

if __name__ == '__main__':
    raise SystemExit(main())
