"""Linux/WSL: real SWAKS against a loopback-only SMTP sink; local HTTPS test."""
import argparse
import contextlib
import http.client
import importlib.util
import io
import json
import os
from pathlib import Path
import shlex
import shutil
import socketserver
import ssl
import subprocess
import tempfile
import threading
import unittest
from unittest.mock import patch
import campaign

ROOT = Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('landing',ROOT/'landing-pages'/'server.py')
landing=importlib.util.module_from_spec(spec);spec.loader.exec_module(landing)

class Sink(socketserver.StreamRequestHandler):
    def handle(self):
        self.connection.settimeout(10)
        self.wfile.write(b'220 localhost rehearsal\r\n')
        while True:
            line=self.rfile.readline(65536)
            if not line: return
            command=line.upper()
            if command.startswith((b'EHLO',b'HELO')): self.wfile.write(b'250 localhost\r\n')
            elif command.startswith(b'MAIL FROM:'): self.wfile.write(b'250 sender accepted\r\n')
            elif command.startswith(b'RCPT TO:'):
                self.wfile.write(b'550 recipient rejected\r\n' if b'REJECT@' in command else b'250 recipient accepted\r\n')
            elif command.startswith(b'DATA'):
                self.wfile.write(b'354 continue\r\n'); data=[]
                while True:
                    part=self.rfile.readline(65536)
                    if part in (b'.\r\n', b''): break
                    data.append(part)
                self.server.messages.append(b''.join(data));self.wfile.write(b'250 queued locally\r\n')
            elif command.startswith(b'QUIT'):
                self.wfile.write(b'221 bye\r\n');return
            else: self.wfile.write(b'502 unsupported\r\n')

class Integration(unittest.TestCase):
    @unittest.skipUnless(os.name == 'posix' and (shutil.which('swaks') or (ROOT/'third-party'/'swaks'/'swaks').exists()), 'Needs Linux and SWAKS')
    def test_real_swaks_send_and_probe(self):
        with tempfile.TemporaryDirectory() as temp, socketserver.ThreadingTCPServer(('127.0.0.1',0),Sink) as smtp:
            smtp.messages=[]
            thread=threading.Thread(target=smtp.serve_forever,daemon=True);thread.start()
            try:
                shim=Path(temp)/'swaks'
                installed=shutil.which('swaks')
                executable=shlex.quote(installed) if installed else 'perl '+shlex.quote(str(ROOT/'third-party'/'swaks'/'swaks'))
                shim.write_text('#!/bin/sh\nexec '+executable+' "$@"\n');shim.chmod(0o700)
                args=argparse.Namespace(targets=ROOT/'rehearsal-targets.txt',template=ROOT/'templates'/'psp-alert.eml',max_recipients=10,
                    delay=0,port=smtp.server_address[1],send=True,probe=False,server='127.0.0.1',approved_targets=ROOT/'rehearsal-targets.txt',
                    sender='sender@example.test',name='Local rehearsal',output=Path(temp)/'send',link='http://127.0.0.1:8080/psp-login.html',tls='none')
                with patch.dict(os.environ,{'PATH':temp+os.pathsep+os.environ['PATH']}),contextlib.redirect_stdout(io.StringIO()):
                    self.assertEqual(campaign.run(args),0)
                    self.assertEqual(len(smtp.messages),2)
                    self.assertTrue(all(b'PLACEHOLDER' not in m and b'http://127.0.0.1:8080/psp-login.html' in m for m in smtp.messages))
                    targets=Path(temp)/'probe.txt';targets.write_text('reject@example.test\naccept@example.test')
                    args.targets=args.approved_targets=targets;args.send=False;args.probe=True;args.output=Path(temp)/'probe'
                    self.assertEqual(campaign.run(args),1)
                    results=json.loads(next(args.output.glob('*/results.json')).read_text())
                    self.assertEqual([r['outcome'] for r in results],['rejected','accepted'])
                    self.assertEqual(len(smtp.messages),2) # RCPT probes never sent DATA.
            finally:
                smtp.shutdown();thread.join()

    @unittest.skipUnless(os.name == 'posix','Uses Linux openssl')
    def test_https_certificate_and_page(self):
        with tempfile.TemporaryDirectory() as temp:
            cert=Path(temp)/'cert.pem';key=Path(temp)/'key.pem'
            subprocess.run(['openssl','req','-x509','-newkey','rsa:2048','-nodes','-keyout',str(key),'-out',str(cert),'-days','1',
                '-subj','/CN=localhost','-addext','subjectAltName=DNS:localhost,IP:127.0.0.1'],check=True,capture_output=True)
            with landing.SimulationServer(('127.0.0.1',0),ROOT/'landing-pages',Path(temp)/'events.jsonl') as server:
                context=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);context.load_cert_chain(cert,key)
                server.socket=context.wrap_socket(server.socket,server_side=True)
                thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
                try:
                    client=http.client.HTTPSConnection('127.0.0.1',server.server_port,context=ssl.create_default_context(cafile=str(cert)),timeout=5)
                    client.request('GET','/psp-login.html');response=client.getresponse()
                    self.assertEqual(response.status,200);self.assertIn(b'<form',response.read());client.close()
                finally:server.shutdown();thread.join()

if __name__=='__main__': unittest.main(verbosity=2)
