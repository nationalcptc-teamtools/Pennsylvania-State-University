# PSU phishing toolkit


- `toolkit/`: generic code, templates, pages, tests and SWAKS source.
- `team-only/`: our tailored templates/pages and unverified recipient candidates.

## Try it

New Kali, from `toolkit/`: `bash setup-kali.sh`. This needs package-repository Internet
access and sudo/root for installation; it installs dependencies and runs local tests.
For an already prepared machine: `bash setup-kali.sh --check` (no installs).
Fresh Kali installation itself has not been tested here; Linux tests ran on Ubuntu/WSL.

Python 3.10+. From `toolkit/` (use `python3` on Linux):

```sh
python -m unittest test_local -v
python campaign.py rehearsal-targets.txt
python landing-pages/server.py
```

Inspect the rendered `.eml` files under `private-output/run-*/` in a mail viewer.
Open **http://127.0.0.1:8080/psp-login.html**, submit dummy values, and inspect
`private-output/events.jsonl`. Stop with Ctrl+C. These commands send no email.

Other pages: `/mfa-setup.html`, `/ai-platform.html`.
To preview our tailored pages, add `--dir ../team-only/landing-pages` to the server command.
To render a tailored email, pass `../team-only/templates/psp-alert.eml` after the recipient file.

## SMTP and deployment

Use Linux/Kali/WSL with Perl and SWAKS. The bundled source can be used with:

```sh
chmod +x bin/swaks
export PATH="$PWD/bin:$PATH"
swaks --version
python3 -m unittest test_local test_integration -v
```

Perl modules/CA certificates still need to be available; source alone is not a complete runtime.
The integration test also needs `openssl`. A normal distro SWAKS package is another option.

Rendering is the default. To send, supply the actual approved configuration:

```sh
python3 campaign.py test-recipient.txt templates/psp-alert.eml \
  --sender exercise@example.test --name 'Exercise' \
  --link https://exercise.lab.example:8443/psp-login.html \
  --server smtp.lab.example --port 25 --tls starttls \
  --approved-targets approved-recipients.txt --max-recipients 1 --send
```

Replace the example values. Remove `--send` to preview first. `--probe` performs a RCPT-only
network check instead. Default cap: 10 recipients; delay: 30 seconds. No SMTP AUTH support.
The shell launchers wrap the same Python CLI; old environment-variable options are removed.

For recipient access, bind the server to the approved interface using `--bind IP`.
HTTPS requires `--ssl --cert /absolute/cert.pem --key /absolute/key.pem`; a port number alone
does not enable TLS. The certificate must match the URL and be trusted. Keep keys/logs outside
the served directory. Localhost URLs only work on the machine running the server.

## Limits and checks

- Logs record views/submissions only. Passwords and other form values are discarded.
- No MFA bypass, executable attachments, remote shell or per-recipient click tracking.
- DMARC `p=none` does not guarantee delivery. SMTP acceptance is not inbox placement.

