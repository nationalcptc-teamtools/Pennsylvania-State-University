#!/usr/bin/env bash
# Run with bash. Installs dependencies, then runs loopback-only tests.
set -euo pipefail
cd -- "$(dirname -- "$0")"
case "${1:-}" in
  '')
    command -v apt-get >/dev/null || { echo 'Needs Kali/Debian apt-get.' >&2; exit 1; }
    elevate=()
    if [ "$(id -u)" -ne 0 ]; then elevate=(sudo); fi
    "${elevate[@]}" apt-get update
    "${elevate[@]}" apt-get install -y python3 swaks openssl ca-certificates libnet-ssleay-perl libnet-dns-perl
    ;;
  --check) ;; # No installation or package-manager network access.
  *) echo 'Usage: bash setup-kali.sh [--check]' >&2; exit 2 ;;
esac
python3 -c 'import sys; sys.exit(0 if sys.version_info >= (3,10) else "Python 3.10+ required")'
command -v swaks >/dev/null || { echo 'SWAKS missing.' >&2; exit 1; }
command -v openssl >/dev/null || { echo 'openssl missing.' >&2; exit 1; }
perl -MNet::SSLeay -MNet::DNS -e 'print "Perl TLS/DNS modules available\n"'
swaks --version
python3 -B -m unittest test_local test_integration -v
echo 'Local checks passed. Next: python3 campaign.py rehearsal-targets.txt'
echo 'Then: python3 landing-pages/server.py'
