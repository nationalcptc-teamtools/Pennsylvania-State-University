"""Offline regression tests: loopback HTTP and mocked SMTP subprocess only."""
import argparse
import contextlib
from email import policy
from email.parser import BytesParser
import http.client
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import tempfile
import threading
import unittest
from unittest.mock import patch
import campaign

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('landing', ROOT/'landing-pages'/'server.py')
landing = importlib.util.module_from_spec(spec)
spec.loader.exec_module(landing)

class CampaignTests(unittest.TestCase):
    def test_all_templates_and_escaped_links(self):
        for file in (ROOT/'templates').glob('*.eml'):
            raw = campaign.render(file, 'test@example.test', 'http://127.0.0.1:8080/psp-login.html?a=1&b=2', 'sender@example.test', 'Test')
            msg = BytesParser(policy=policy.default).parsebytes(raw)
            self.assertEqual(msg['To'], 'test@example.test')
            self.assertEqual(len(msg.get_all('From')), 1)
            self.assertIsNotNone(msg['Message-ID'])
            self.assertNotIn(b'PLACEHOLDER', raw)
            for part in msg.walk():
                self.assertFalse(part.defects)
                if part.get_content_type() == 'text/html':
                    self.assertIn('a=1&amp;b=2', part.get_content())

    def test_bad_link_rejected(self):
        for link in ['javascript:alert(1)', 'https://YOUR_LANDING_PAGE', 'https://a:b@example.test/', 'https://example.test/\r\nX: a']:
            with self.assertRaises(ValueError):
                campaign.render(ROOT/'templates'/'psp-alert.eml', 'a@example.test', link, 'b@example.test', 'Test')

    def test_recipient_normalization(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp)/'targets.txt'
            path.write_bytes(b'  # comment\r\n\r\na@example.test\r\na@example.test\r\nb@example.test')
            self.assertEqual(campaign.addresses(path), ['a@example.test', 'b@example.test'])

    def test_rcpt_stage_not_quit(self):
        self.assertEqual(campaign.classify_rcpt(' -> RCPT TO:<a@example.test>\n<** 550 denied\n -> QUIT\n <- 221 bye'), ('rejected', 550))
        self.assertEqual(campaign.classify_rcpt(' ~> RCPT TO:<a@example.test>\n<~ 250 accepted\n ~> QUIT\n<~ 221 bye'), ('accepted', 250))
        self.assertEqual(campaign.classify_rcpt(' <- 250 hello\n <- 221 bye'), ('indeterminate', None))

    def args(self, temp):
        return argparse.Namespace(targets=ROOT/'rehearsal-targets.txt', template=ROOT/'templates'/'psp-alert.eml',
            max_recipients=10, delay=0, port=2525, send=False, probe=False, server=None,
            approved_targets=None, sender='sender@example.test', name='Test', output=Path(temp),
            link='http://127.0.0.1:8080/psp-login.html', tls='none')

    def test_default_never_calls_swaks(self):
        with tempfile.TemporaryDirectory() as temp, patch('campaign.subprocess.run') as run, contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(campaign.run(self.args(temp)), 0)
            run.assert_not_called()
            result = json.loads(next(Path(temp).glob('*/results.json')).read_text())
            self.assertTrue(all(x['outcome'] == 'rendered_only' for x in result))

    def test_live_requires_configuration(self):
        with tempfile.TemporaryDirectory() as temp, patch('campaign.subprocess.run') as run:
            args = self.args(temp); args.send = True
            with self.assertRaises(ValueError): campaign.run(args)
            run.assert_not_called()

    def test_allowlist_enforced(self):
        with tempfile.TemporaryDirectory() as temp, patch('campaign.subprocess.run') as run:
            args = self.args(temp); args.send = True; args.server = '127.0.0.1'
            args.approved_targets = Path(temp)/'approved.txt'; args.approved_targets.write_text('someone@example.test')
            with self.assertRaises(ValueError): campaign.run(args)
            run.assert_not_called()

    def test_failure_does_not_abort_second_recipient(self):
        with tempfile.TemporaryDirectory() as temp, patch('campaign.shutil.which', return_value='swaks'), patch('campaign.subprocess.run') as run, contextlib.redirect_stdout(io.StringIO()):
            args = self.args(temp); args.send = True; args.server = '127.0.0.1'; args.approved_targets = args.targets
            run.side_effect = [subprocess.CompletedProcess([], 1, 'failed', ''), subprocess.CompletedProcess([], 0, 'accepted', '')]
            self.assertEqual(campaign.run(args), 1)
            self.assertEqual(run.call_count, 2)
            records = json.loads(next(Path(temp).glob('*/results.json')).read_text())
            self.assertEqual([r['outcome'] for r in records], ['failed','smtp_accepted'])

class ServerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.directory = Path(self.temp.name)/'pages'; self.directory.mkdir()
        for name in ['psp-login.html','mfa-setup.html','ai-platform.html']:
            (self.directory/name).write_text('<form method="POST" action="/capture"></form>')
        for name in ['captured_creds.log','server.py','key.pem']:
            (self.directory/name).write_text('PRIVATE_SENTINEL')
        self.log = Path(self.temp.name)/'private'/'events.jsonl'
        self.server = landing.SimulationServer(('127.0.0.1',0), self.directory,self.log)
        self.thread = threading.Thread(target=self.server.serve_forever,daemon=True); self.thread.start()

    def tearDown(self):
        self.server.shutdown(); self.server.server_close(); self.thread.join(); self.temp.cleanup()

    def request(self, method, path, body=None, headers=None):
        connection = http.client.HTTPConnection('127.0.0.1',self.server.server_port,timeout=3)
        connection.request(method,path,body=body,headers=headers or {})
        response = connection.getresponse(); result=(response.status,dict(response.getheaders()),response.read());connection.close();return result

    def test_allowlisted_pages_and_blocked_files(self):
        for page in landing.PAGES: self.assertEqual(self.request('GET',page)[0],200)
        for page in ['/','/server.py','/captured_creds.log','/key.pem','/../events.jsonl','/%2e%2e/private/events.jsonl','/psp-login.html/../key.pem']:
            self.assertEqual(self.request('GET',page)[0],404)

    def test_secrets_never_persist(self):
        status,headers,_ = self.request('POST','/capture','email=PRIVATE_EMAIL&password=SECRET_TEST_PASSWORD',{'Content-Type':'application/x-www-form-urlencoded'})
        self.assertEqual(status,303);self.assertEqual(headers['Location'],'/complete')
        text=self.log.read_text();self.assertNotIn('SECRET_TEST_PASSWORD',text);self.assertNotIn('PRIVATE_EMAIL',text)
        self.assertEqual(json.loads(text)['event'],'form_submitted')

    def test_bad_requests(self):
        self.assertEqual(self.request('POST','/other','x')[0],404)
        self.assertEqual(self.request('POST','/capture','{}',{'Content-Type':'application/json'})[0],415)
        self.assertEqual(self.request('POST','/capture','',{'Content-Type':'application/x-www-form-urlencoded','Content-Length':'-1'})[0],400)
        self.assertEqual(self.request('POST','/capture','x'*8193,{'Content-Type':'application/x-www-form-urlencoded'})[0],413)

    def test_refuses_log_inside_root(self):
        with self.assertRaises(ValueError):
            landing.SimulationServer(('127.0.0.1',0),self.directory,self.directory/'events.log')

if __name__ == '__main__':
    unittest.main(verbosity=2)
